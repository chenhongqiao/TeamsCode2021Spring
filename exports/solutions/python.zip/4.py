N = input()

print(str(N[::-1]))