#include <bits/stdc++.h>
using namespace std;
int main()
{
    cout << "  _____     ____" << endl;
    cout << " |_ \" _| U /\"___|" << endl;
    cout << "   | |   \\| | u" << endl;
    cout << "  /| |\\   | |/__" << endl;
    cout << " u |_|U    \\____|" << endl;
    cout << " _// \\\\_  _// \\\\" << endl;
    cout << "(__) (__)(__)(__)" << endl;
    return 0;
}
