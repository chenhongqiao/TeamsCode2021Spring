
public class program {
    public static void main(String[] args) {
        System.out.println("  _____     ____  ");
        System.out.println(" |_ \" _| U /\"___| ");
        System.out.println("   | |   \\| | u   ");
        System.out.println("  /| |\\   | |/__  ");
        System.out.println(" u |_|U    \\____| ");
        System.out.println(" _// \\\\_  _// \\\\  ");
        System.out.println("(__) (__)(__)(__) ");
    }
}
